package ar.poo.pokemon.dylan.java.pokemones.todos_los_pokemones;

import java.util.ArrayList;
import java.util.List;

import ar.poo.pokemon.dylan.java.enums.ListaDeTiposDePokemons;
import ar.poo.pokemon.dylan.java.generador_de_pokemones.Randomizador;
import ar.poo.pokemon.dylan.java.generador_de_pokemones.Rango;
import ar.poo.pokemon.dylan.java.pokemones.ListaDePokemones;
import ar.poo.pokemon.dylan.java.pokemones.Pokemon;

public class Snorlax extends Pokemon{
    private ListaDeTiposDePokemons tipo1 = ListaDeTiposDePokemons.NORMAL;
    private ListaDeTiposDePokemons tipo2 = ListaDeTiposDePokemons.NINGUNO;
    private static final Rango[] rangos = new Rango[6];
    private double altura = 0;
    private double peso = 0;
    private String color = null;
    public Snorlax(double altura, double peso, String color) {
        super(  Randomizador.generarEstadisticas(rangos[0].min, rangos[0].max),
                Randomizador.generarEstadisticas(rangos[1].min, rangos[1].max),
                Randomizador.generarEstadisticas(rangos[2].min, rangos[2].max),
                Randomizador.generarEstadisticas(rangos[3].min, rangos[3].max),
                Randomizador.generarEstadisticas(rangos[4].min, rangos[4].max),
                Randomizador.generarEstadisticas(rangos[5].min, rangos[5].max));
        this.altura = altura;
        this.peso = peso;
        this.color = color;
        ListaDePokemones.agregarPokemon(this);
    }

    static{
        rangos[0] = new Rango(150, 200);  
        rangos[1] = new Rango(100, 130);  
        rangos[2] = new Rango(60, 80);    
        rangos[3] = new Rango(60, 80);    
        rangos[4] = new Rango(100, 130);  
        rangos[5] = new Rango(15, 35);    
    }
    @Override
    public String toString() {
        int numero = 0;
        for (Pokemon p : ListaDePokemones.pokemones) {
            if (p instanceof Snorlax) {
                numero++;
            }
            if(p == this){
                break;
            }
        }
        return "--Snorlax " + numero;
        /* return "Snorlax: \n" + getPs() + 
        "\n"+ getAtaque() + 
        "\n" + getDefensa() + 
        "\n" + getAtaqueEspecial() + 
        "\n" + getDefensaEspecial() + 
        "\n" + getVelocidad(); */
    }

    
}
