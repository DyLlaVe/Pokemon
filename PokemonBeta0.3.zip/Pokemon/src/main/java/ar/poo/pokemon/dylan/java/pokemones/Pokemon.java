package ar.poo.pokemon.dylan.java.pokemones;
import java.util.List;

import lombok.Getter;
@Getter

public abstract class Pokemon {
    private int[] estadisticas = {0,0,0,0,0,0};

    public Pokemon(int PS, int ataque, int defensa, int ataqueEspecial, int defensaEspecial, int velocidad) {
        this.estadisticas[0] = PS;
        this.estadisticas[1] = ataque;
        this.estadisticas[2] = defensa;
        this.estadisticas[3] = ataqueEspecial;
        this.estadisticas[4] = defensaEspecial;
        this.estadisticas[5] = velocidad;
    }
}
