package ar.poo.pokemon.dylan.java.juego;

import ar.poo.pokemon.dylan.java.pokemones.ListaDePokemones;
import ar.poo.pokemon.dylan.java.pokemones.Pokemon;

import java.util.Scanner;

public class Peleas {
    public static void elejirPokemon(){
        Scanner teclado = new Scanner(System.in);
        System.out.println(ListaDePokemones.pokemones);
        System.out.println("ELEGI UN POKEMON PARA EL JUGADOR 1: del 0 al " + (ListaDePokemones.pokemones.size()-1));
        int eleccion1 = teclado.nextInt();
        Pokemon jugador1 = ListaDePokemones.pokemones.get(eleccion1);
        System.out.println("Tu eleccion fue: " + jugador1);
        System.out.println("ELEGI UN POKEMON PARA EL JUGADOR 2: del 0 al " + (ListaDePokemones.pokemones.size()-1) + ". Excepto el " + eleccion1);
        int eleccion2 = teclado.nextInt();
        if (eleccion1 == eleccion2) {
            System.out.println("No se puede ese pokemon");
            System.exit(0);
        }
        Pokemon jugador2 = ListaDePokemones.pokemones.get(eleccion2);
        System.out.println("Tu eleccion fue: " + jugador2);
        Peleas.interfaces(jugador1,jugador2);
    }
    public static void interfaces(Pokemon jugador1,Pokemon jugador2){
    }
}
