package ar.poo.pokemon.dylan.java.movimientos;

import java.util.ArrayList;
import java.util.List;

public class ListaDeMovimientos {
    private static List<Movimiento> listaDeMovimientos = new ArrayList<>();

    public static void agregarMovimiento(Movimiento movimiento){
        listaDeMovimientos.add(movimiento);
    }
}
