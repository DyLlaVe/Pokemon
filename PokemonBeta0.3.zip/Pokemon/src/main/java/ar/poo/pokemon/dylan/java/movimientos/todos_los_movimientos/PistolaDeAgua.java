package ar.poo.pokemon.dylan.java.movimientos.todos_los_movimientos;

import ar.poo.pokemon.dylan.java.enums.ListaDeEfectos;
import ar.poo.pokemon.dylan.java.enums.ListaDeTiposDeMovimientos;
import ar.poo.pokemon.dylan.java.enums.ListaDeTiposDePokemons;
import ar.poo.pokemon.dylan.java.movimientos.ListaDeMovimientos;
import ar.poo.pokemon.dylan.java.movimientos.Movimiento;
import lombok.Getter;

@Getter

public class PistolaDeAgua extends Movimiento{
    private ListaDeTiposDePokemons tipo = ListaDeTiposDePokemons.AGUA;
    private ListaDeEfectos efecto = ListaDeEfectos.NINGUNO;
    private int danioBase = 12;
    private int probabilidadImpacto = 90;

    public PistolaDeAgua() {
        super(ListaDeTiposDeMovimientos.FISICO);
        ListaDeMovimientos.agregarMovimiento(this);
    }

    
}
