package ar.poo.pokemon.dylan.java.pokemones;
import java.util.List;

import ar.poo.pokemon.dylan.java.generador_de_pokemones.Randomizador;
import ar.poo.pokemon.dylan.java.movimientos.Movimiento;
import lombok.Getter;
@Getter

public abstract class Pokemon {
    public int id;
    private int[] estadisticas = {0,0,0,0,0,0};
    public Movimiento[] movimientos = new Movimiento[4];

    public Pokemon(int PS, int ataque, int defensa, int ataqueEspecial, int defensaEspecial, int velocidad) {
        this.estadisticas[0] = PS;
        this.estadisticas[1] = ataque;
        this.estadisticas[2] = defensa;
        this.estadisticas[3] = ataqueEspecial;
        this.estadisticas[4] = defensaEspecial;
        this.estadisticas[5] = velocidad;
        this.movimientos = new Movimiento[4];
    }
}
