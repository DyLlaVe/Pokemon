package ar.poo.pokemon.dylan.java.movimientos.todos_los_movimientos;

import ar.poo.pokemon.dylan.java.enums.ListaDeEfectos;
import ar.poo.pokemon.dylan.java.enums.ListaDeTiposDeMovimientos;
import ar.poo.pokemon.dylan.java.enums.ListaDeTiposDePokemons;
import ar.poo.pokemon.dylan.java.movimientos.ListaDeMovimientos;
import ar.poo.pokemon.dylan.java.movimientos.Movimiento;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class Rayo extends Movimiento{
    private ListaDeTiposDePokemons tipo = ListaDeTiposDePokemons.ELECTRICO;
    private ListaDeEfectos efecto = ListaDeEfectos.PARALIZADO;
    private int danio = 20;
    private int probabilidadImpacto = 90;

    public Rayo() {
        super(ListaDeTiposDeMovimientos.FISICO);
        ListaDeMovimientos.agregarMovimiento(this);
    }

    
}
