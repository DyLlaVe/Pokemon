package ar.poo.pokemon.dylan.java.generador_de_pokemones;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import ar.poo.pokemon.dylan.java.movimientos.ListaDeMovimientos;
import ar.poo.pokemon.dylan.java.movimientos.Movimiento;
import ar.poo.pokemon.dylan.java.pokemones.Pokemon;

public class Randomizador {
    private static int idUnica = 1;
    public static int generarEstadisticas(int rangoInicial, int rangoFinal){
        Random r = new Random();
        return r.nextInt(rangoFinal - rangoInicial + 1) + rangoInicial;
    }
    public static void elejirMovimiento(Pokemon pokemon){
        Random r = new Random();
        List<Movimiento> movimientosDisponibles = new ArrayList<>();
        for (int i = 0; i < ListaDeMovimientos.listaDeMovimientos.size();i++){
            movimientosDisponibles.add(ListaDeMovimientos.listaDeMovimientos.get(i));
        }
        for(int i = 0; i < pokemon.movimientos.length;i++){
            int numeroAleatorio = r.nextInt(movimientosDisponibles.size());
            Movimiento movimiento = movimientosDisponibles.get(numeroAleatorio);
            pokemon.movimientos[i] = movimiento;
            movimientosDisponibles.remove(numeroAleatorio);
        } 
    }
    public static int idUnica(){
        return idUnica++;
    }
}
