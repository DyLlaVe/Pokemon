package ar.poo.pokemon.dylan.java.pokemones.todos_los_pokemones;

import java.util.ArrayList;
import java.util.List;

import ar.poo.pokemon.dylan.java.enums.ListaDeTiposDePokemons;
import ar.poo.pokemon.dylan.java.generador_de_pokemones.Randomizador;
import ar.poo.pokemon.dylan.java.generador_de_pokemones.Rango;
import ar.poo.pokemon.dylan.java.pokemones.ListaDePokemones;
import ar.poo.pokemon.dylan.java.pokemones.Pokemon;

public class Gyarados extends Pokemon {
    private static int idUnica = 1;
    private ListaDeTiposDePokemons tipo1 = ListaDeTiposDePokemons.AGUA;
    private ListaDeTiposDePokemons tipo2 = ListaDeTiposDePokemons.VOLADOR;
    private static final Rango[] rangos = new Rango[6];
    private double altura = 0;
    private double peso = 0;
    private String color = null;
    public Gyarados(double altura, double peso, String color) {
        super(  Randomizador.generarEstadisticas(rangos[0].min, rangos[0].max),
                Randomizador.generarEstadisticas(rangos[1].min, rangos[1].max),
                Randomizador.generarEstadisticas(rangos[2].min, rangos[2].max),
                Randomizador.generarEstadisticas(rangos[3].min, rangos[3].max),
                Randomizador.generarEstadisticas(rangos[4].min, rangos[4].max),
                Randomizador.generarEstadisticas(rangos[5].min, rangos[5].max));
        this.id = idUnica++;
        Randomizador.elejirMovimiento(this);
        this.altura = altura;
        this.peso = peso;
        this.color = color;
        ListaDePokemones.agregarPokemon(this);
    }

    static{
        rangos[0] = new Rango(90, 110); 
        rangos[1] = new Rango(115, 140);  
        rangos[2] = new Rango(65, 90);   
        rangos[3] = new Rango(50, 75);   
        rangos[4] = new Rango(80, 115);   
        rangos[5] = new Rango(70, 100);  
    }
    @Override
    public String toString() {
        return "--Gyarados " + id;

        /* return "Gyarados: \n" + getPs() + 
        "\n"+ getAtaque() + 
        "\n" + getDefensa() + 
        "\n" + getAtaqueEspecial() + 
        "\n" + getDefensaEspecial() + 
        "\n" + getVelocidad(); */

        /* return "Gyarados: \n" + movimientos[0] + 
                        "\n" + movimientos[1] + 
                        "\n" + movimientos[2] + 
                        "\n" + movimientos[3]; */
    }

    
}
