package ar.poo.pokemon.dylan.java.movimientos;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;

@Getter

public class ListaDeMovimientos {
    public static List<Movimiento> listaDeMovimientos = new ArrayList<>();

    public static void agregarMovimiento(Movimiento movimiento){
        listaDeMovimientos.add(movimiento);
    }
}
