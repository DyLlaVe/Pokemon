package ar.poo.pokemon.dylan.java.pokemones;

import ar.poo.pokemon.dylan.java.pokemones.todos_los_pokemones.Gyarados;
import ar.poo.pokemon.dylan.java.pokemones.todos_los_pokemones.Pikachu;
import ar.poo.pokemon.dylan.java.pokemones.todos_los_pokemones.Snorlax;

public class IniciarPokemones {
    public static void iniciarPokemones(){
        Pikachu pikachu = new Pikachu(0.4, 6.0, "Amarillo");
        Pikachu pikachu2 = new Pikachu(0.45, 6.2, "Amarillo claro");
        Snorlax snorlax = new Snorlax(2.1, 460.0, "Azul");
        Gyarados gyarados = new Gyarados(6.5, 235.0, "Celeste");
        Pikachu pikachu3 = new Pikachu(0.40, 6.2, "Amarillo");
    }
}
