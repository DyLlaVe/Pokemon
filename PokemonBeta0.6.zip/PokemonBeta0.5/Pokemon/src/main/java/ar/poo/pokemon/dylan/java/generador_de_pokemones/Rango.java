package ar.poo.pokemon.dylan.java.generador_de_pokemones;

public class Rango {
    public int min;
    public int max;

    public Rango(int min, int max) {
        this.min = min;
        this.max = max;
    }
}
