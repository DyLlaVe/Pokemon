CREATE DATABASE IF NOT EXISTS pokemon;
USE pokemon;

DROP TABLE IF EXISTS pokemones;

CREATE TABLE pokemones(
    id int auto_increment primary key,
    nombre varchar(100) not null check(length(nombre)>=3),
    estadisticas_PS int not null,
    estadisticas_At int not null,
    estadisticas_Df int not null,
    estadisticas_AE int not null,
    estadisticas_DE int not null,
    estadisticas_Ve int not null,
    tipo1 int not null,
    tipo2 int
);

CREATE TABLE pokemones_movimientos_tipos(
    id int auto_increment primary key,
    nombre varchar(100) not null check(length(nombre)>=3),
    fuerteContra int not null,
    debilContra int not null
)

CREATE TABLE movimientos(
    id int auto_increment primary key,
    nombre varchar(100) not null check(length(nombre)>=3),
    tipo_Movimiento enum('FISICO', 'ESPECIAL', 'ESTADO'),
    tipo int not null,
    efecto int not null,
    danio_Base int,
    probabilidad_Base int not null
)

CREATE TABLE efectos(
    id int auto_increment primary key,
    nombre varchar(100) not null check(length(nombre)>=3),
    descripcion varchar(100) not null
)

ALTER TABLE pokemones_movimientos_tipos add constraint FK_pokemones_tipos
foreign key (id) references pokemones(tipo1);

ALTER TABLE pokemones_movimientos_tipos add constraint FK_pokemones_tipos2
foreign key (id) references pokemones(tipo2);

