package ar.poo.pokemon.dylan.java.generador_de_pokemones;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import ar.poo.pokemon.dylan.java.movimientos.ListaDeMovimientos;
import ar.poo.pokemon.dylan.java.movimientos.Movimiento;
import ar.poo.pokemon.dylan.java.pokemones.Pokemon;

public class ElejirMovimiento {
    public static void elejirMovimiento(Pokemon pokemon){
        Random r = new Random();
        List<Movimiento> movimientosDisponibles = new ArrayList<>();
        for (int i = 0; i < ListaDeMovimientos.listaDeMovimientos.size();i++){
            movimientosDisponibles.add(ListaDeMovimientos.listaDeMovimientos.get(i));
        }
        for(int i = 0; i < pokemon.movimientos.length;i++){
            int numeroAleatorio = r.nextInt(movimientosDisponibles.size());
            Movimiento movimiento = movimientosDisponibles.get(numeroAleatorio);
            pokemon.movimientos[i] = movimiento;
            movimientosDisponibles.remove(numeroAleatorio);
        }
        
    }
}
