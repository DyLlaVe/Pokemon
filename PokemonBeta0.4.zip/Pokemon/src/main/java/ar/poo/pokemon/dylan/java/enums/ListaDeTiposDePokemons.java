package ar.poo.pokemon.dylan.java.enums;

import java.util.Arrays;
import java.util.List;
import lombok.Getter;

@Getter

public enum ListaDeTiposDePokemons {
    ELECTRICO(null,null),
    NORMAL(null,null),
    FUEGO(null,null),
    AGUA(null,null),
    TIERRA(null,null),
    PLANTA(null,null),
    METAL(null, null),
    LUCHA(null,null),
    PSIQUICO(null,null),
    HIELO(null,null),
    VENENO(null,null),
    VOLADOR(null,null),
    BICHO(null,null),
    ROCA(null,null),
    FANTASMA(null,null),
    DRAGON(null, null),
    SINIESTRO(null,null),
    HADA(null,null),
    NINGUNO(
        Arrays.asList(),
        Arrays.asList()
    );

    private List<ListaDeTiposDePokemons> fuerteContra = null;
    private List<ListaDeTiposDePokemons> debilContra = null;

    private ListaDeTiposDePokemons(List<ListaDeTiposDePokemons> fuerteContra, List<ListaDeTiposDePokemons> debilContra) {
        this.fuerteContra = fuerteContra;
        this.debilContra = debilContra;
    }
    static{
        ELECTRICO.fuerteContra = Arrays.asList(ListaDeTiposDePokemons.AGUA,ListaDeTiposDePokemons.VOLADOR);
        ELECTRICO.debilContra = Arrays.asList(ListaDeTiposDePokemons.TIERRA);

        NORMAL.fuerteContra = Arrays.asList();
        NORMAL.debilContra = Arrays.asList(ListaDeTiposDePokemons.LUCHA);

        FUEGO.fuerteContra = Arrays.asList(ListaDeTiposDePokemons.PLANTA, ListaDeTiposDePokemons.HIELO, ListaDeTiposDePokemons.BICHO, ListaDeTiposDePokemons.METAL);
        FUEGO.debilContra = Arrays.asList(ListaDeTiposDePokemons.AGUA, ListaDeTiposDePokemons.TIERRA, ListaDeTiposDePokemons.ROCA);
    
        AGUA.fuerteContra = Arrays.asList(ListaDeTiposDePokemons.FUEGO, ListaDeTiposDePokemons.TIERRA, ListaDeTiposDePokemons.ROCA);
        AGUA.debilContra = Arrays.asList(ListaDeTiposDePokemons.PLANTA, ListaDeTiposDePokemons.ELECTRICO);

        TIERRA.fuerteContra = Arrays.asList(ListaDeTiposDePokemons.FUEGO, ListaDeTiposDePokemons.ELECTRICO, ListaDeTiposDePokemons.VENENO, ListaDeTiposDePokemons.ROCA, ListaDeTiposDePokemons.METAL);
        TIERRA.debilContra = Arrays.asList(ListaDeTiposDePokemons.AGUA, ListaDeTiposDePokemons.PLANTA, ListaDeTiposDePokemons.HIELO);
    
        PLANTA.fuerteContra = Arrays.asList(ListaDeTiposDePokemons.AGUA, ListaDeTiposDePokemons.TIERRA, ListaDeTiposDePokemons.ROCA);
        PLANTA.debilContra = Arrays.asList(ListaDeTiposDePokemons.FUEGO, ListaDeTiposDePokemons.HIELO, ListaDeTiposDePokemons.VOLADOR, ListaDeTiposDePokemons.BICHO, ListaDeTiposDePokemons.VENENO);
    
        METAL.fuerteContra = Arrays.asList(ListaDeTiposDePokemons.HIELO, ListaDeTiposDePokemons.ROCA, ListaDeTiposDePokemons.HADA);
        METAL.debilContra = Arrays.asList(ListaDeTiposDePokemons.FUEGO, ListaDeTiposDePokemons.LUCHA, ListaDeTiposDePokemons.TIERRA);

        LUCHA.fuerteContra = Arrays.asList(ListaDeTiposDePokemons.NORMAL, ListaDeTiposDePokemons.ROCA, ListaDeTiposDePokemons.SINIESTRO, ListaDeTiposDePokemons.HIELO, ListaDeTiposDePokemons.METAL);
        LUCHA.debilContra = Arrays.asList(ListaDeTiposDePokemons.PSIQUICO, ListaDeTiposDePokemons.VOLADOR, ListaDeTiposDePokemons.HADA);
    
        PSIQUICO.fuerteContra = Arrays.asList(ListaDeTiposDePokemons.LUCHA, ListaDeTiposDePokemons.VENENO);
        PSIQUICO.debilContra = Arrays.asList(ListaDeTiposDePokemons.BICHO, ListaDeTiposDePokemons.FANTASMA, ListaDeTiposDePokemons.SINIESTRO);
    
        HIELO.fuerteContra = Arrays.asList(ListaDeTiposDePokemons.PLANTA, ListaDeTiposDePokemons.TIERRA, ListaDeTiposDePokemons.VOLADOR, ListaDeTiposDePokemons.DRAGON);
        HIELO.debilContra = Arrays.asList(ListaDeTiposDePokemons.FUEGO, ListaDeTiposDePokemons.LUCHA, ListaDeTiposDePokemons.ROCA, ListaDeTiposDePokemons.METAL);
    
        VENENO.fuerteContra = Arrays.asList(ListaDeTiposDePokemons.PLANTA, ListaDeTiposDePokemons.HADA);
        VENENO.debilContra = Arrays.asList(ListaDeTiposDePokemons.TIERRA, ListaDeTiposDePokemons.PSIQUICO);

        VOLADOR.fuerteContra = Arrays.asList(ListaDeTiposDePokemons.PLANTA, ListaDeTiposDePokemons.LUCHA, ListaDeTiposDePokemons.BICHO);
        VOLADOR.debilContra = Arrays.asList(ListaDeTiposDePokemons.ELECTRICO, ListaDeTiposDePokemons.HIELO, ListaDeTiposDePokemons.ROCA);
    
        BICHO.fuerteContra = Arrays.asList(ListaDeTiposDePokemons.PLANTA, ListaDeTiposDePokemons.PSIQUICO, ListaDeTiposDePokemons.SINIESTRO);
        BICHO.debilContra = Arrays.asList(ListaDeTiposDePokemons.FUEGO, ListaDeTiposDePokemons.VOLADOR, ListaDeTiposDePokemons.ROCA);
    
        ROCA.fuerteContra = Arrays.asList(ListaDeTiposDePokemons.FUEGO, ListaDeTiposDePokemons.HIELO, ListaDeTiposDePokemons.VOLADOR, ListaDeTiposDePokemons.BICHO);
        ROCA.debilContra = Arrays.asList(ListaDeTiposDePokemons.AGUA, ListaDeTiposDePokemons.PLANTA, ListaDeTiposDePokemons.LUCHA, ListaDeTiposDePokemons.TIERRA, ListaDeTiposDePokemons.METAL);
    
        FANTASMA.fuerteContra = Arrays.asList(ListaDeTiposDePokemons.FANTASMA, ListaDeTiposDePokemons.PSIQUICO);
        FANTASMA.debilContra = Arrays.asList(ListaDeTiposDePokemons.FANTASMA, ListaDeTiposDePokemons.SINIESTRO);

        DRAGON.fuerteContra = Arrays.asList(ListaDeTiposDePokemons.DRAGON);
        DRAGON.debilContra = Arrays.asList(ListaDeTiposDePokemons.HIELO, ListaDeTiposDePokemons.HADA);

        SINIESTRO.fuerteContra = Arrays.asList(ListaDeTiposDePokemons.PSIQUICO, ListaDeTiposDePokemons.FANTASMA);
        SINIESTRO.debilContra = Arrays.asList(ListaDeTiposDePokemons.LUCHA, ListaDeTiposDePokemons.BICHO, ListaDeTiposDePokemons.HADA);
    
        HADA.fuerteContra = Arrays.asList(ListaDeTiposDePokemons.LUCHA, ListaDeTiposDePokemons.DRAGON, ListaDeTiposDePokemons.SINIESTRO);
        HADA.debilContra = Arrays.asList(ListaDeTiposDePokemons.VENENO, ListaDeTiposDePokemons.METAL);
    }

    
}
