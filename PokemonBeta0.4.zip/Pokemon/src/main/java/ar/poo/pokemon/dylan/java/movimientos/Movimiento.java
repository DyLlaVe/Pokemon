package ar.poo.pokemon.dylan.java.movimientos;

import ar.poo.pokemon.dylan.java.enums.ListaDeTiposDeMovimientos;
import lombok.ToString;
@ToString
public abstract class Movimiento {
    private ListaDeTiposDeMovimientos efecto = null;

    public Movimiento(ListaDeTiposDeMovimientos efecto) {
        this.efecto = efecto;
    }

    
}
