package ar.poo.pokemon.dylan.java.generador_de_pokemones;

import java.util.Random;

public class Randomizador {
    
    public static int generarEstadisticas(int rangoInicial, int rangoFinal){
        Random r = new Random();
        return r.nextInt(rangoFinal - rangoInicial + 1) + rangoInicial;
    }
}
