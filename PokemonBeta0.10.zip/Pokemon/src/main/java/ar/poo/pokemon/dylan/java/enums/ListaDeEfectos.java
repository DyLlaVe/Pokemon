package ar.poo.pokemon.dylan.java.enums;

public enum ListaDeEfectos {
    PARALIZADO(10), 
    ENVENENADO(20), 
    CONGELADO(15), 
    DORMIDO(10), 
    QUEMADO(15), 
    CONFUSO(10),
    NINGUNO(0);

    private int probabilidadBase = 0;

    private ListaDeEfectos(int probabilidadBase){
        this.probabilidadBase = probabilidadBase;
    }
}
