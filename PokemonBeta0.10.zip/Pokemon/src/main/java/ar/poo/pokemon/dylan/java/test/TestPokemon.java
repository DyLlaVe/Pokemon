package ar.poo.pokemon.dylan.java.test;

import ar.poo.pokemon.dylan.java.enums.ListaDeTiposDePokemons;
import ar.poo.pokemon.dylan.java.juego.Peleas;
import ar.poo.pokemon.dylan.java.movimientos.todos_los_movimientos.Araniar;
import ar.poo.pokemon.dylan.java.movimientos.todos_los_movimientos.PistolaDeAgua;
import ar.poo.pokemon.dylan.java.movimientos.todos_los_movimientos.Placaje;
import ar.poo.pokemon.dylan.java.movimientos.todos_los_movimientos.Rayo;
import ar.poo.pokemon.dylan.java.pokemones.ListaDePokemones;
import ar.poo.pokemon.dylan.java.pokemones.Pokemon;
import ar.poo.pokemon.dylan.java.pokemones.todos_los_pokemones.Gyarados;
import ar.poo.pokemon.dylan.java.pokemones.todos_los_pokemones.Pikachu;
import ar.poo.pokemon.dylan.java.pokemones.todos_los_pokemones.Snorlax;

public class TestPokemon {
    public static void main(String[] args) {
        Araniar araniar = new Araniar();
        PistolaDeAgua pistolaDeAgua = new PistolaDeAgua();
        Placaje placaje = new Placaje();
        Rayo rayo = new Rayo();

        Pikachu pikachu = new Pikachu(0.4, 6.0, "Amarillo");
        Pikachu pikachu2 = new Pikachu(0.45, 6.2, "Amarillo claro");
        Snorlax snorlax = new Snorlax(2.1, 460.0, "Azul");
        Gyarados gyarados = new Gyarados(6.5, 235.0, "Celeste");
        Pikachu pikachu3 = new Pikachu(0.40, 6.2, "Amarillo");

        

        /* Peleas.elejirPokemon(); */
        System.out.println(pikachu);
        System.out.println(pikachu2);
        System.out.println(pikachu3);
    }
}
