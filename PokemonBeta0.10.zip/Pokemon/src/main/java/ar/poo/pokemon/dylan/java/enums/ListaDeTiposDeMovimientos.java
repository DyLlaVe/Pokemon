package ar.poo.pokemon.dylan.java.enums;

public enum ListaDeTiposDeMovimientos {
    FISICO,
    ESPECIAL,
    ESTADO
}
