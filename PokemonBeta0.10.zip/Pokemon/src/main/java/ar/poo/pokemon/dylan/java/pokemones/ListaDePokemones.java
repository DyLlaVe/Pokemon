package ar.poo.pokemon.dylan.java.pokemones;

import java.util.ArrayList;
import java.util.List;

public class ListaDePokemones {
    public static List<Pokemon> pokemones = new ArrayList<>();

    public static void agregarPokemon(Pokemon pokemon){
        pokemones.add(pokemon);
    }
}
