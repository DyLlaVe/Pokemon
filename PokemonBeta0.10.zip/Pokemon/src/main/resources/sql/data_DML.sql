insert into pokemones_movimientos_tipos(nombre) values
    ('Electrico'),
    ('Normal'),
    ('Fuego'),
    ('Agua'),
    ('Tierra'), 
    ('Planta'),
    ('Metal'),
    ('Lucha'),
    ('Psiquico'),
    ('Hielo'), 
    ('Veneno'),
    ('Volador'),
    ('Bicho'),
    ('Roca'),
    ('Fantasma'),
    ('Dragon'),
    ('Siniestro'),
    ('Hada'),
    ('Ninguno');

insert into relaciones_tipos(tipo_id,relacion_id,relacion) values
    (1,4,'fuerte'),(1,12,'fuerte'),
    (1,5,'debil'),

    (2,8,'debil'),

    (3,6,'fuerte'),(3,10,'fuerte'),(3,13,'fuerte'),(3,7,'fuerte'),
    (3,4,'debil'),(3,5,'debil'),(3,14,'debil'),

    (4, 3, 'fuerte'),(4, 5, 'fuerte'),(4, 14, 'fuerte'),
    (4, 6, 'debil'),(4, 1, 'debil'),

    (5, 3, 'fuerte'),(5, 1, 'fuerte'),(5, 11, 'fuerte'),(5, 14, 'fuerte'),(5, 7, 'fuerte'),
    (5, 4, 'debil'),(5, 6, 'debil'),(5, 10, 'debil'),

    (6, 4, 'fuerte'),(6, 5, 'fuerte'),(6, 14, 'fuerte'),
    (6, 3, 'debil'),(6, 10, 'debil'),(6, 12, 'debil'),(6, 13, 'debil'),(6, 11, 'debil'),

    (7, 10, 'fuerte'),(7, 14, 'fuerte'),(7, 18, 'fuerte'),
    (7, 3, 'debil'),(7, 8, 'debil'),(7, 5, 'debil'),

    (8, 2, 'fuerte'),(8, 14, 'fuerte'),(8, 17, 'fuerte'),(8, 10, 'fuerte'),(8, 7, 'fuerte'),
    (8, 9, 'debil'),(8, 12, 'debil'),(8, 18, 'debil'),

    (9, 8, 'fuerte'),(9, 11, 'fuerte'),
    (9, 13, 'debil'),(9, 15, 'debil'),(9, 17, 'debil'),

    (10, 6, 'fuerte'),(10, 5, 'fuerte'),(10, 12, 'fuerte'),(10, 16, 'fuerte'),
    (10, 3, 'debil'),(10, 8, 'debil'),(10, 14, 'debil'),(10, 7, 'debil'),

    (11, 6, 'fuerte'),(11, 18, 'fuerte'),
    (11, 5, 'debil'),(11, 9, 'debil'),

    (12, 6, 'fuerte'),(12, 8, 'fuerte'),(12, 13, 'fuerte'),
    (12, 1, 'debil'),(12, 10, 'debil'),(12, 14, 'debil'),

    (13, 6, 'fuerte'),(13, 9, 'fuerte'),(13, 17, 'fuerte'),
    (13, 3, 'debil'),(13, 12, 'debil'),(13, 14, 'debil'),

    (14, 3, 'fuerte'),(14, 10, 'fuerte'),(14, 12, 'fuerte'),(14, 13, 'fuerte'),
    (14, 4, 'debil'),(14, 6, 'debil'),(14, 8, 'debil'),(14, 5, 'debil'),(14, 7, 'debil'),

    (15, 15, 'fuerte'),(15, 9, 'fuerte'),
    (15, 15, 'debil'),(15, 17, 'debil'),

    (16, 16, 'fuerte'),
    (16, 10, 'debil'),(16, 18, 'debil'),

    (17, 9, 'fuerte'),(17, 15, 'fuerte'),
    (17, 8, 'debil'),(17, 13, 'debil'),(17, 18, 'debil'),

    (18, 8, 'fuerte'),(18, 16, 'fuerte'),(18, 17, 'fuerte'),
    (18, 11, 'debil'),(18, 7, 'debil');

insert into pokemones (nombre, estadisticas_PS, estadisticas_At, estadisticas_Df, estadisticas_AE, estadisticas_DE, estadisticas_Ve, tipo1, tipo2) values
	('Pikachu', 35, 55, 40, 50, 50, 90, 1, null),
	('Charizard', 78, 84, 78, 109, 85, 100, 3, 12),
	('Blastoise', 79, 83, 100, 85, 105, 78, 4, null),
	('Venusaur', 80, 82, 83, 100, 100, 80, 6, 11),
	('Machamp', 90, 130, 80, 65, 85, 55, 8, null),
	('Alakazam', 55, 50, 45, 135, 95, 120, 9, null),
	('Gengar', 60, 65, 60, 130, 75, 110, 15, 11),
	('Gyarados', 95, 125, 79, 60, 100, 81, 4, 12),
	('Snorlax', 160, 110, 65, 65, 110, 30, 2, null),
	('Dragonite', 91, 134, 95, 100, 100, 80, 16, 12),
	('Lucario', 70, 110, 70, 115, 70, 90, 8, 7),
	('Sylveon', 95, 65, 65, 110, 130, 60, 18, null),
	('Tyranitar', 100, 134, 110, 95, 100, 61, 14, 17);
    
insert into efectos (nombre, descripcion) values
	('Paralizar', 'Puede paralizar al objetivo'),
	('Dormir', 'Hace que el objetivo se duerma'),
	('Quemar', 'Puede causar quemaduras'),
	('Congelar', 'Puede congelar al oponente'),
	('Envenenar', 'Puede causar envenenamiento'),
	('Bajar Defensa', 'Disminuye la defensa del oponente'),
	('Aumentar Ataque', 'Aumenta el ataque del usuario'),
	('Sin Efecto', 'No causa efectos secundarios');
    
insert into movimientos (nombre, tipo_Movimiento, tipo, efecto, danio_Base, probabilidad_Base) values
	('Impactrueno', 'ESPECIAL', 1, 1, 40, 100),        
	('Lanzallamas', 'ESPECIAL', 3, 3, 90, 100),        
	('Hidrobomba', 'ESPECIAL', 4, 8, 110, 80),         
	('Hoja Afilada', 'FISICO', 6, 8, 70, 100),      
	('Terremoto', 'FISICO', 5, 8, 100, 100),       
	('Psíquico', 'ESPECIAL', 9, 6, 90, 100),          
	('Puño Fuego', 'FISICO', 3, 3, 75, 100),           
	('Rayo Hielo', 'ESPECIAL', 10, 4, 90, 100),        
	('Colmillo Veneno', 'FISICO', 11, 5, 50, 100),     
	('Canto', 'ESTADO', 2, 2, null, 55),               
	('Danza Espada', 'ESTADO', 2, 7, null, 100),       
	('Chispazo', 'ESPECIAL', 1, 1, 80, 100),            
	('Ala de Acero', 'FISICO', 12, 8, 70, 90),          
	('Golpe Cuerpo', 'FISICO', 2, 1, 85, 100);        
    
insert into pokemones_movimientos (id_pokemon, id_movimiento) values
	(1, 1),  
	(1, 12), 
	(1, 14),  
	(1, 10), 

	(2, 2),
	(2, 7), 
	(2, 13),  
	(2, 5),  

	(3, 3),  
	(3, 5), 
	(3, 14), 
	(3, 8),  

	(4, 4), 
	(4, 9),   
	(4, 11),  
	(4, 10),  

	(5, 14), 
	(5, 11), 
	(5, 5), 
	(5, 7),  

	(6, 6),  
	(6, 10), 
	(6, 8),  
	(6, 11), 

	(7, 6),
	(7, 9),  
	(7, 10),
	(7, 2),  

	(8, 3),  
	(8, 14),  
	(8, 5),   
	(8, 13),  

	(9, 14), 
	(9, 10), 
	(9, 2),   
	(9, 5),  

	(10, 8),
	(10, 5),
	(10, 13),
	(10, 11),

	(11, 11),
	(11, 13),
	(11, 14),
	(11, 7),  

	(12, 10),
	(12, 6),  
	(12, 4),  
	(12, 14),

	(13, 5),
	(13, 7),
	(13, 14),
	(13, 2);