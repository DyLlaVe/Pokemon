select * from pokemones;

select * from movimientos;

select * from efectos;

select 
    p.nombre nombre_pokemon,
    m.nombre nombre_movimiento,
    tipos.nombre tipo_movimiento,
    m.tipo_del_movimiento,
    m.danio_Base,
    m.probabilidad_Base
from pokemones p
join pokemones_movimientos pm on p.id = pm.id_pokemon
join movimientos m on pm.id_movimiento = m.id
join pokemones_movimientos_tipos tipos on m.tipo = tipos.id
order by nombre_pokemon;

select 
    t1.nombre tipo,
    r.relacion tipo_de_relacion,
    t2.nombre relacionado_con
from relaciones_tipos r
join pokemones_movimientos_tipos t1 on r.tipo_id = t1.id
join pokemones_movimientos_tipos t2 on r.relacion_id = t2.id
order by t1.nombre, r.relacion;

