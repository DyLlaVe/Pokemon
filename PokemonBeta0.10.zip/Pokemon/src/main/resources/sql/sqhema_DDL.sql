CREATE DATABASE IF NOT EXISTS pokemon;
USE pokemon;

drop table if exists pokemones;
drop table if exists pokemones_movimientos_tipos;
drop table if exists movimientos;
drop table if exists efectos;
drop table if exists pokemones_movimientos;
drop table if exists relaciones_tipos;

create table pokemones_movimientos_tipos(
    id int auto_increment primary key,
    nombre varchar(100) not null check(length(nombre)>=3)
);

create table pokemones(
    id int auto_increment primary key,
    nombre varchar(100) not null check(length(nombre)>=3),
    estadisticas_PS int not null,
    estadisticas_At int not null,
    estadisticas_Df int not null,
    estadisticas_AE int not null,
    estadisticas_DE int not null,
    estadisticas_Ve int not null,
    tipo1 int not null,
    tipo2 int,
    foreign key (tipo1) references pokemones_movimientos_tipos(id),
    foreign key (tipo2) references pokemones_movimientos_tipos(id)
);

create table efectos(
    id int auto_increment primary key,
    nombre varchar(100) not null check(length(nombre)>=3),
    descripcion varchar(100) not null
);

create table movimientos(
    id int auto_increment primary key,
    nombre varchar(100) not null check(length(nombre)>=3),
    tipo_Movimiento enum('FISICO', 'ESPECIAL', 'ESTADO') not null,
    tipo int not null,
    efecto int not null,
    danio_Base int,
    probabilidad_Base int not null,
    foreign key (tipo) references pokemones_movimientos_tipos(id),
    foreign key (efecto) references efectos(id)
);

create table pokemones_movimientos(
    id_pokemon int not null,
    id_movimiento int not null,
    primary key(id_pokemon,id_movimiento),
    foreign key (id_pokemon) references pokemones(id),
    foreign key (id_movimiento) references movimientos(id)
);

create table relaciones_tipos(
    tipo_id int not null,
    relacion_id int not null,
    relacion enum ('fuerte','debil') not null,
    primary key (tipo_id,relacion_id,relacion),
    foreign key (tipo_id) references pokemones_movimientos_tipos(id),
    foreign key (relacion_id) references pokemones_movimientos_tipos(id)  
);






